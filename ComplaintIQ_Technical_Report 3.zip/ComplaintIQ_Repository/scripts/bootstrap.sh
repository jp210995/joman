#!/usr/bin/env bash
set -euo pipefail
export AWS_REGION=us-east-1
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
export PYTHONPATH="$PWD/src"
python -m complaintiq.models
python - <<'PY'
import boto3
from complaintiq.config import REGION,bucket_name
s3=boto3.client('s3',region_name=REGION); b=bucket_name()
try:s3.head_bucket(Bucket=b);print('Bucket exists',b)
except Exception:s3.create_bucket(Bucket=b);print('Created',b)
PYCODE
