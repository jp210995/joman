#!/usr/bin/env bash
set -euo pipefail
source .venv/bin/activate
export PYTHONPATH="$PWD/src" AWS_REGION=us-east-1
python -m complaintiq.download_data
python -m complaintiq.prepare
python -m complaintiq.indexing
B=$(python -c 'from complaintiq.config import bucket_name;print(bucket_name())')
aws s3 sync data/ "s3://$B/complaintiq/data/" --region us-east-1 --quiet
aws s3 sync index/ "s3://$B/complaintiq/index/" --region us-east-1 --quiet
