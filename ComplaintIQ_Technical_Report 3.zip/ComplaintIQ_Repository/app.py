import sys,uuid,streamlit as st
sys.path.insert(0,'src')
from langgraph.types import Command
from complaintiq.graph import app
st.set_page_config(page_title='ComplaintIQ',layout='wide');st.title('ComplaintIQ');st.caption('Human-reviewed complaint intelligence and regulatory remediation copilot')
tid=st.session_state.setdefault('tid',str(uuid.uuid4()));cfg={'configurable':{'thread_id':tid}}
req=st.text_area('Paste a complaint or ask an analytics/regulatory question',height=180)
if st.button('Run',type='primary') and req:app.invoke({'request':req,'thread_id':tid},cfg)
snap=app.get_state(cfg)
if snap.next:
 p=snap.tasks[0].interrupts[0].value;st.subheader('Draft awaiting human approval');st.markdown(p['draft']);edit=st.text_area('Edit before approval',p['draft'],height=250)
 c1,c2,c3=st.columns(3)
 if c1.button('Approve'):app.invoke(Command(resume={'action':'approve'}),cfg);st.rerun()
 if c2.button('Save edit and approve'):app.invoke(Command(resume={'action':'edit','text':edit}),cfg);st.rerun()
 if c3.button('Reject'):app.invoke(Command(resume={'action':'reject'}),cfg);st.rerun()
elif snap.values.get('draft'):
 st.markdown(snap.values['draft']);st.code(snap.values.get('report_uri','Not published'))
 with st.expander('Execution trace'):st.json(snap.values.get('trace',[]))
