from pathlib import Path
import pandas as pd

HOME = Path.home()

SOURCE = HOME / "cfpb_archive" / "extracted"
OUTPUT = HOME / "data" / "raw" / "cfpb"

OUTPUT.mkdir(parents=True, exist_ok=True)

PRODUCTS = {
    "Credit card": "credit_card.csv",
    "Checking or savings account": "checking_or_savings_account.csv",
}

files = sorted(SOURCE.rglob("*.csv"))

if len(files) != 5:
    raise RuntimeError(
        f"Expected 5 archive CSV files, found {len(files)}"
    )

print("Archive files:")
for f in files:
    print(" -", f.name)

required = [
    "Date received",
    "Product",
    "Sub-product",
    "Issue",
    "Sub-issue",
    "Consumer complaint narrative",
    "Company",
    "State",
    "Tags",
    "Submitted via",
    "Company response to consumer",
    "Timely response?",
    "Complaint ID",
]

frames = []

for f in files:
    print("\nReading:", f.name)

    # Read only the columns ComplaintIQ needs.
    df = pd.read_csv(
        f,
        usecols=required,
        dtype=str,
        keep_default_na=False,
        low_memory=False
    )

    print("  raw rows:", len(df))

    # Parse and constrain dates.
    df["Date received"] = pd.to_datetime(
        df["Date received"],
        errors="coerce"
    )

    df = df[
        (df["Date received"] >= "2026-01-01")
        &
        (df["Date received"] <= "2026-06-30")
    ]

    # Keep only project products.
    df = df[
        df["Product"].isin(PRODUCTS.keys())
    ]

    # Require an actual narrative.
    df["Consumer complaint narrative"] = (
        df["Consumer complaint narrative"]
        .astype(str)
        .str.strip()
    )

    df = df[
        df["Consumer complaint narrative"] != ""
    ]

    print("  qualifying rows:", len(df))

    frames.append(df)

combined = pd.concat(
    frames,
    ignore_index=True
)

print("\nRows before deduplication:", len(combined))

# Complaint ID must uniquely identify complaints.
combined = combined.drop_duplicates(
    subset=["Complaint ID"],
    keep="first"
)

print("Rows after deduplication:", len(combined))

# Normalize names to what ComplaintIQ expects.
combined = combined.rename(
    columns={
        "Date received": "date_received",
        "Product": "product",
        "Sub-product": "sub_product",
        "Issue": "issue",
        "Sub-issue": "sub_issue",
        "Consumer complaint narrative":
            "consumer_complaint_narrative",
        "Company": "company",
        "State": "state",
        "Tags": "tags",
        "Submitted via": "submitted_via",
        "Company response to consumer":
            "company_response_to_consumer",
        "Timely response?": "timely_response",
        "Complaint ID": "complaint_id",
    }
)

combined["date_received"] = (
    combined["date_received"]
    .dt.strftime("%Y-%m-%d")
)

print("\n=== FINAL DATASET ===")

print(
    combined.groupby("product")
    .size()
    .to_string()
)

print("\nDate range:")
print(
    combined["date_received"].min(),
    "to",
    combined["date_received"].max()
)

print(
    "\nDuplicate complaint IDs:",
    combined["complaint_id"].duplicated().sum()
)

print(
    "Empty narratives:",
    (
        combined["consumer_complaint_narrative"]
        .str.strip()
        == ""
    ).sum()
)

print("\nNarrative lengths:")

lengths = (
    combined["consumer_complaint_narrative"]
    .str.len()
)

print("minimum:", lengths.min())
print("median :", int(lengths.median()))
print("maximum:", lengths.max())

# Produce the two source files expected by ComplaintIQ.
for product, filename in PRODUCTS.items():

    out = combined[
        combined["product"] == product
    ].copy()

    path = OUTPUT / filename

    out.to_csv(
        path,
        index=False
    )

    print(
        "\nWrote:",
        path,
        "rows:",
        len(out)
    )

print("\nDONE")
