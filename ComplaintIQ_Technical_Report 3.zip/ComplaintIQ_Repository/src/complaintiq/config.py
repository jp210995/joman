import os, pathlib, boto3
REGION=os.getenv("AWS_REGION","us-east-1")
ROOT=pathlib.Path(os.getenv("COMPLAINTIQ_ROOT", pathlib.Path(__file__).resolve().parents[2]))
DATA=ROOT/"data"; RAW=DATA/"raw"; PROC=DATA/"processed"; INDEX=ROOT/"index"; STATE=ROOT/"state"; REPORTS=ROOT/"reports"; EVAL=ROOT/"eval"
for p in (RAW,PROC,INDEX,STATE,REPORTS,EVAL): p.mkdir(parents=True,exist_ok=True)
def account_id(): return boto3.client("sts",region_name=REGION).get_caller_identity()["Account"]
def bucket_name(): return os.getenv("COMPLAINTIQ_BUCKET",f"sagemaker-complaintiq-{account_id()}")
UA={"User-Agent":os.getenv("COMPLAINTIQ_USER_AGENT","ComplaintIQ-capstone/1.0")}
