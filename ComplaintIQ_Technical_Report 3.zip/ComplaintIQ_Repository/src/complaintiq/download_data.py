import hashlib,json,datetime as dt,requests
from .config import RAW,DATA,UA
API="https://www.consumerfinance.gov/data-research/consumer-complaints/search/api/v1/"; ECFR="https://www.ecfr.gov/api/versioner/v1"
PRODUCTS=["Credit card","Checking or savings account"]; WINDOW=("2026-01-01","2026-06-30")
PARTS={"1005":"Reg E","1026":"Reg Z","1022":"Reg V","1006":"Reg F","1030":"Reg DD"}
PDFS={
"sh_issue17_2018-09.pdf":"https://files.consumerfinance.gov/f/documents/bcfp_supervisory-highlights_issue-17_2018-09.pdf",
"sh_issue18_2019-03.pdf":"https://files.consumerfinance.gov/f/documents/cfpb_supervisory-highlights_issue-18_032019.pdf",
"sh_issue22_2020-09.pdf":"https://files.consumerfinance.gov/f/documents/cfpb_supervisory-highlights_issue-22_2020-09.pdf",
"sh_issue23_2021-01.pdf":"https://files.consumerfinance.gov/f/documents/cfpb_supervisory-highlights_issue-23_2021-01.pdf",
"exam_manual_v2_2012.pdf":"https://files.consumerfinance.gov/f/201210_cfpb_supervision-and-examination-manual-v2.pdf"}
def main():
 manifest=[]
 def fetch(url,out,params=None):
  out.parent.mkdir(parents=True,exist_ok=True)
  if not out.exists():
   with requests.get(url,params=params,headers=UA,stream=True,timeout=300) as r:
    r.raise_for_status()
    with out.open('wb') as f:
     for chunk in r.iter_content(1<<20): f.write(chunk)
  b=out.read_bytes(); manifest.append({"file":str(out.relative_to(DATA)),"url":requests.Request("GET",url,params=params).prepare().url,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"retrieved_utc":dt.datetime.now(dt.timezone.utc).isoformat()})
 for p in PRODUCTS: fetch(API,RAW/'cfpb'/(p.lower().replace(' ','_')+'.csv'),{"product":p,"has_narrative":"true","format":"csv","no_aggs":"true","date_received_min":WINDOW[0],"date_received_max":WINDOW[1]})
 titles=requests.get(f"{ECFR}/titles.json",headers=UA,timeout=60).json()["titles"]; asof=next(t for t in titles if t["number"]==12)["up_to_date_as_of"]
 for part in PARTS: fetch(f"{ECFR}/full/{asof}/title-12.xml",RAW/'ecfr'/f'12cfr{part}.xml',{"part":part})
 for n,u in PDFS.items():
  out=RAW/'pdf'/n; fetch(u,out)
  if out.read_bytes()[:5]!=b'%PDF-': raise ValueError(f'{n} is not a PDF')
 (DATA/'manifest.json').write_text(json.dumps(manifest,indent=2)); print(f'Downloaded/verified {len(manifest)} files')
if __name__=='__main__': main()
