import json,re,hashlib,boto3,numpy as np,faiss,duckdb,pickle
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from rank_bm25 import BM25Okapi
from botocore.config import Config
from .config import REGION,INDEX,PROC,DATA
br=boto3.client('bedrock-runtime',region_name=REGION,config=Config(retries={'max_attempts':12,'mode':'adaptive'})); CACHE=INDEX/'embed_cache';CACHE.mkdir(exist_ok=True)
def one(text):
 k=CACHE/(hashlib.sha1(text.encode()).hexdigest()+'.npy')
 if k.exists():return np.load(k)
 r=br.invoke_model(modelId='amazon.titan-embed-text-v2:0',body=json.dumps({'inputText':text[:12000],'dimensions':1024,'normalize':True}));v=np.array(json.loads(r['body'].read())['embedding'],dtype='float32');np.save(k,v);return v
def embed(texts):
 with ThreadPoolExecutor(2) as ex:return np.vstack(list(ex.map(one,texts)))
def tok(s):return re.findall(r'[a-z0-9]+(?:\.[0-9]+)?',s.lower())
class HybridIndex:
 def __init__(self,chunks,vecs=None):
  self.chunks=chunks;self.vecs=embed([c['text'] for c in chunks]) if vecs is None else vecs; self.faiss=faiss.IndexFlatIP(self.vecs.shape[1]);self.faiss.add(self.vecs);self.bm25=BM25Okapi([tok(c['text']) for c in chunks])
 def search(self,q,k=8,pool=40):
  _,dense=self.faiss.search(embed([q]),min(pool,len(self.chunks)));sparse=np.argsort(self.bm25.get_scores(tok(q)))[::-1][:pool];score=defaultdict(float)
  for ranking in (dense[0],sparse):
   for r,i in enumerate(ranking):
    if i>=0:score[int(i)]+=1/(61+r)
  return [{**self.chunks[i],'rrf':round(score[i],5)} for i in sorted(score,key=score.get,reverse=True)[:k]]
def load_jsonl(p):return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
def build():
 regs=load_jsonl(PROC/'reg_chunks.jsonl'); con=duckdb.connect(str(DATA/'complaintiq.duckdb'),read_only=True)
 cases=con.execute("SELECT complaint_id,product,issue,company_response,timely,narrative text FROM v_complaints WHERE date_received < DATE '2026-06-01' USING SAMPLE 3000 ROWS (reservoir,42)").df().to_dict('records')
 for name,rows in [('reg',regs),('case',cases)]:
  vecs=embed([r['text'] for r in rows]);np.save(INDEX/f'{name}_vectors.npy',vecs);(INDEX/f'{name}_chunks.json').write_text(json.dumps(rows));print(name,len(rows))
def load(name):return HybridIndex(json.loads((INDEX/f'{name}_chunks.json').read_text()),np.load(INDEX/f'{name}_vectors.npy'))
if __name__=='__main__':build()
