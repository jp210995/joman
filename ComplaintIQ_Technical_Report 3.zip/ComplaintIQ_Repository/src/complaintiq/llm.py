import json,hashlib,sqlite3,time,boto3
from botocore.config import Config
from botocore.exceptions import ClientError
from pydantic import ValidationError
from .config import REGION,ROOT,STATE
MODELS=json.loads((ROOT/'models.json').read_text()) if (ROOT/'models.json').exists() else {}
br=boto3.client('bedrock-runtime',region_name=REGION,config=Config(retries={'max_attempts':12,'mode':'adaptive'},read_timeout=180))
_cache=sqlite3.connect(str(STATE/'llm_cache.sqlite'),check_same_thread=False); _cache.execute('CREATE TABLE IF NOT EXISTS c(k TEXT PRIMARY KEY,v TEXT)'); _no_temp=set(); LEDGER=[]
def chat(model_id,system,user,max_tokens=1500,temperature=0.0,use_cache=True):
 key=hashlib.sha256(json.dumps([model_id,system,user,max_tokens]).encode()).hexdigest(); hit=_cache.execute('SELECT v FROM c WHERE k=?',(key,)).fetchone()
 if use_cache and hit:return hit[0]
 cfg={'maxTokens':max_tokens};
 if model_id not in _no_temp:cfg['temperature']=temperature
 t=time.time()
 try:r=br.converse(modelId=model_id,system=[{'text':system}],messages=[{'role':'user','content':[{'text':user}]}],inferenceConfig=cfg)
 except ClientError as e:
  if 'temperature' in str(e).lower() and model_id not in _no_temp:_no_temp.add(model_id);return chat(model_id,system,user,max_tokens,temperature,use_cache)
  raise
 text=r['output']['message']['content'][0]['text']; u=r.get('usage',{}); LEDGER.append({'model':model_id,'input_tokens':u.get('inputTokens',0),'output_tokens':u.get('outputTokens',0),'latency_ms':int((time.time()-t)*1000)})
 _cache.execute('INSERT OR REPLACE INTO c VALUES(?,?)',(key,text));_cache.commit();return text
def chat_json(model_id,system,user,schema,**kw):
 system+='\nReturn ONLY one JSON object. No prose or markdown.'; raw=chat(model_id,system,user,**kw)
 for attempt in range(2):
  try:return schema.model_validate_json(raw[raw.index('{'):raw.rindex('}')+1])
  except (ValueError,ValidationError) as e:
   if attempt:raise
   raw=chat(model_id,system,user+f'\nRepair invalid JSON: {e}. Schema: {schema.model_json_schema()}',use_cache=False,**kw)
