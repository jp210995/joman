import json
import boto3

from .config import REGION, ROOT

TEXT_MODEL = "amazon.nova-pro-v1:0"
EMBED_MODEL = "amazon.titan-embed-text-v2:0"


def main():

    client = boto3.client(
        "bedrock-runtime",
        region_name=REGION
    )

    print("Testing Amazon Nova Pro...")

    response = client.converse(
        modelId=TEXT_MODEL,
        messages=[
            {
                "role": "user",
                "content": [
                    {"text": "Reply exactly: COMPLAINTIQ_OK"}
                ]
            }
        ],
        inferenceConfig={
            "maxTokens": 20
        }
    )

    result = response["output"]["message"]["content"][0]["text"]

    print("Nova response:", result)

    models = {
        "worker": TEXT_MODEL,
        "judge": TEXT_MODEL,
        "fast": TEXT_MODEL,
        "embed": EMBED_MODEL
    }

    output = ROOT / "models.json"

    output.write_text(
        json.dumps(models, indent=2)
    )

    print("\nComplaintIQ models:")
    print(json.dumps(models, indent=2))

    print("\nSaved to:", output)


if __name__ == "__main__":
    main()
