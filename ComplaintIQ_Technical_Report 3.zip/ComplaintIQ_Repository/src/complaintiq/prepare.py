import json,re,duckdb
from lxml import etree
from pypdf import PdfReader
from .config import DATA,RAW,PROC
DB=DATA/'complaintiq.duckdb'
def chunks(rec,max_chars=3000,overlap=400):
 paras=rec['text'].split('\n'); out=[]; buf=''
 for p in paras:
  if len(buf)+len(p)>max_chars and buf: out.append(buf); buf=buf[-overlap:]
  buf+=("\n" if buf else "")+p
 if buf: out.append(buf)
 page=f"-p{rec['page']}" if rec.get('page') else ''
 return [{**rec,'chunk_id':f"{rec['doc_id']}{page}-c{i}",'text':t} for i,t in enumerate(out)]
def main():
 con=duckdb.connect(str(DB)); glob=str(RAW/'cfpb'/'*.csv')
 con.execute(f"CREATE OR REPLACE TABLE complaints_raw AS SELECT * FROM read_csv_auto('{glob}',header=true,normalize_names=true,all_varchar=true)")
 cols={r[0] for r in con.execute('DESCRIBE complaints_raw').fetchall()}; need={'complaint_id','date_received','product','issue','consumer_complaint_narrative'}
 if not need<=cols: raise RuntimeError(f'Missing required CSV columns: {need-cols}. Existing: {sorted(cols)}')
 opt=lambda n,alias: f'{n} AS {alias}' if n in cols else f'NULL AS {alias}'
 sql=f"CREATE OR REPLACE VIEW v_complaints AS SELECT CAST(complaint_id AS BIGINT) complaint_id,CAST(date_received AS DATE) date_received,product,{opt('sub_product','sub_product')},issue,{opt('sub_issue','sub_issue')},{opt('company','company')},{opt('state','state')},{opt('tags','tags')},{opt('submitted_via','submitted_via')},{opt('company_response_to_consumer','company_response')},{opt('timely_response','timely')},consumer_complaint_narrative narrative FROM complaints_raw QUALIFY ROW_NUMBER() OVER(PARTITION BY complaint_id ORDER BY CAST(date_received AS DATE))=1"
 con.execute(sql); print(con.execute('SELECT product,count(*) n,min(date_received),max(date_received) FROM v_complaints GROUP BY 1').df())
 records=[]
 for xp in sorted((RAW/'ecfr').glob('12cfr*.xml')):
  part=xp.stem.replace('12cfr',''); tree=etree.parse(str(xp))
  for div in tree.iter('DIV8'):
   sid=div.get('N','').replace('§','').strip(); body='\n'.join(' '.join(p.itertext()).strip() for p in div.iter('P'))
   if body: records.append({'doc_id':f'12CFR{sid}','source':f'12 CFR {sid}','title':' '.join((div.findtext('HEAD') or '').split()),'part':part,'page':None,'text':body})
 for pdf in sorted((RAW/'pdf').glob('*.pdf')):
  for i,p in enumerate(PdfReader(str(pdf)).pages,1):
   txt=re.sub(r'[ \t]+',' ',re.sub(r'-\n(\w)',r'\1',p.extract_text() or '')).strip()
   if len(txt)>200: records.append({'doc_id':pdf.stem,'source':pdf.name,'page':i,'text':txt})
 allc=[c for r in records for c in chunks(r)]
 with (PROC/'reg_chunks.jsonl').open('w') as f:
  for c in allc: f.write(json.dumps(c)+'\n')
 print('Regulatory chunks:',len(allc))
if __name__=='__main__': main()
